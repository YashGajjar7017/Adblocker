# adblocker
Chrome Extension to block ads
Run in VS Code and click on more tools-> extensions
Enable Developer mode
Click on Load unpacked and select the project folder and load the project on chrome and use the extension to block Youtube ads:)
