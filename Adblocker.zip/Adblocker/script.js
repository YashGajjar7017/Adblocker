setInterval(function(){
    var skipB=document.getElementsByClassName("ytp-ad-skip-button");
    if(skipB!=undefined && skipB.length>0){skipB[0].click();}
},1000)